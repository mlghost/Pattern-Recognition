load digitsNet
layers = net.Layers;
[XTrain,~,YTrain] = digitTrain4DArrayData;
[XValidation,~,YValidation] = digitTest4DArrayData;
disp(size(XTrain));
numResponses = 1;
analyzeNetwork(net);
layers = [
    layers(1:12)
    fullyConnectedLayer(numResponses)
    regressionLayer];
  
%layers(1:12) = freezeWeights(layers(1:12));

options = trainingOptions('adam',...
  'ExecutionEnvironment','gpu',...
    'InitialLearnRate',0.001, ...
    'ValidationData',{XValidation,YValidation},...
    'Plots','training-progress',...
    'Verbose',false);
net = trainNetwork(XTrain,YTrain,layers,options);
